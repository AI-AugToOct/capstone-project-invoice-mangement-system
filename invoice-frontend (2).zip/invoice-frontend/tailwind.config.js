﻿module.exports = {
  content: ["./src/**/*.{js,jsx,ts,tsx}"],
  theme: {
    extend: {
      colors: {
        primary: "#a78bfa",   // بنفسجي فاتح
        secondary: "#38bdf8" // سماوي
      }
    }
  },
  plugins: [],
};
