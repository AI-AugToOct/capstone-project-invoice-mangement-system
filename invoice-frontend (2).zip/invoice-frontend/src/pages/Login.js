﻿import { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const navigate = useNavigate();

  const handleLogin = (e) => {
    e.preventDefault();
    // حالياً يدخل على الداشبورد مباشرة
    navigate("/dashboard");
  };

  return (
    <div className="min-h-screen flex items-center justify-center bg-gradient-to-br from-violet-100 via-sky-50 to-violet-200 p-6">
      {/* البطاقة */}
      <form
        onSubmit={handleLogin}
        className="bg-white/90 backdrop-blur-sm p-8 rounded-2xl shadow-xl w-full max-w-md border border-white/50"
      >
        {/* أيقونة/شعار */}
        <div className="w-12 h-12 rounded-xl bg-gradient-to-r from-violet-400 to-sky-400 text-white grid place-items-center mx-auto shadow mb-4">
          <span className="font-bold">IN</span>
        </div>

        <h1 className="text-2xl font-bold text-center text-violet-700 mb-2">
          Welcome back
        </h1>
        <p className="text-center text-gray-500 mb-6">
          Login to your invoice dashboard
        </p>

        {/* Email */}
        <div className="mb-4">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Email
          </label>
          <input
            type="email"
            placeholder="you@example.com"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
            className="w-full p-3 border rounded-lg outline-none focus:ring-2 focus:ring-violet-400"
          />
        </div>

        {/* Password */}
        <div className="mb-6">
          <label className="block text-sm font-medium text-gray-700 mb-1">
            Password
          </label>
          <input
            type="password"
            placeholder="••••••••"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
            className="w-full p-3 border rounded-lg outline-none focus:ring-2 focus:ring-violet-400"
          />
        </div>

        {/* زر تسجيل الدخول */}
        <button
          type="submit"
          className="w-full py-3 rounded-lg text-white font-medium shadow
                     bg-gradient-to-r from-violet-400 to-sky-400
                     hover:from-violet-500 hover:to-sky-500 transition"
        >
          Login
        </button>

        {/* Divider */}
        <div className="flex items-center gap-3 my-6">
          <div className="h-px flex-1 bg-gray-200" />
          <span className="text-xs text-gray-400">or</span>
          <div className="h-px flex-1 bg-gray-200" />
        </div>

        {/* زر وهمي للتجربة */}
        <button
          type="button"
          className="w-full py-3 rounded-lg text-violet-700 bg-violet-50 hover:bg-violet-100 border border-violet-100 transition"
          onClick={() => navigate("/dashboard")}
        >
          Continue as Guest
        </button>

        {/* Footer */}
        <p className="text-center text-sm text-gray-500 mt-6">
          Don’t have an account?{" "}
          <a
            href="/signup"
            className="text-sky-600 hover:text-sky-700 font-medium"
          >
            Sign up
          </a>
        </p>
      </form>
    </div>
  );
}
