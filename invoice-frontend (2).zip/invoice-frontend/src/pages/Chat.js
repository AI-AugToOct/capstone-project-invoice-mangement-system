import { useState } from "react";

export default function Chat() {
  const [messages, setMessages] = useState([
    { sender: "bot", text: "👋 Ask me anything about your invoices." }
  ]);
  const [input, setInput] = useState("");

  const handleSend = async () => {
    if (!input.trim()) return;

    // أضيف رسالة المستخدم
    const newMessages = [...messages, { sender: "user", text: input }];
    setMessages(newMessages);
    setInput("");

    try {
      // طلب للـ API (بدل الرابط حطي رابط FastAPI)
      const res = await fetch("http://localhost:8000/chat_rag", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ query: input }),
      });

      const data = await res.json();

      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: data.answer || "No response from API." },
      ]);
    } catch (err) {
      setMessages((prev) => [
        ...prev,
        { sender: "bot", text: "⚠️ Failed to fetch answer from backend." },
      ]);
    }
  };

  return (
    <div className="min-h-screen flex flex-col bg-gradient-to-br from-gray-900 via-gray-800 to-gray-900 p-6 rounded-lg shadow">
      <h1 className="text-2xl font-bold text-sky-400 mb-4">Chat with Invoices</h1>

      {/* Messages area */}
      <div className="flex-1 bg-gray-800 p-4 rounded-lg overflow-y-auto space-y-3">
        {messages.map((msg, i) => (
          <div
            key={i}
            className={`p-3 rounded-lg max-w-xs ${
              msg.sender === "user"
                ? "ml-auto bg-gradient-to-r from-violet-500 to-sky-500 text-white shadow"
                : "mr-auto bg-gray-700 text-gray-100"
            }`}
          >
            {msg.text}
          </div>
        ))}
      </div>

      {/* Input area */}
      <div className="border-t border-gray-700 mt-4 pt-3 flex gap-2">
        <input
          value={input}
          onChange={(e) => setInput(e.target.value)}
          placeholder="Ask about your invoices..."
          className="flex-1 p-2 rounded-lg bg-gray-700 text-white border border-gray-600 focus:ring-2 focus:ring-sky-400"
        />
        <button
          onClick={handleSend}
          className="px-4 py-2 rounded-lg text-white shadow 
                     bg-gradient-to-r from-violet-500 to-sky-500 
                     hover:from-violet-600 hover:to-sky-600 transition"
        >
          Send
        </button>
      </div>
    </div>
  );
}
