﻿import { useState } from "react";

export default function UploadInvoice() {
  const [file, setFile] = useState(null);
  const [json, setJson] = useState(null);

  const handleUpload = async () => {
    if (!file) {
      alert("Please choose a file first!");
      return;
    }

    // هنا ترفعين الصورة للباك إند
    // مؤقتاً نعرض بيانات وهمية (mock)
    const mockInvoice = {
      "Invoice Number": "INV-2025-001",
      "Date": "2025-10-01",
      "Vendor": "Demo Vendor",
      "Items": [
        { description: "Item A", quantity: "2", unit_price: "50", total: "100" }
      ],
      "Total Amount": "100",
      "Category": "Office"
    };

    setJson(mockInvoice);
  };

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-violet-100 via-sky-50 to-violet-200">
      <h1 className="text-2xl font-bold text-violet-700 mb-6">Upload Invoice</h1>

      {/* بطاقة رفع الصورة */}
      <div className="bg-white p-6 rounded-xl shadow flex flex-col gap-4">
        <input
          type="file"
          onChange={(e) => setFile(e.target.files[0])}
          className="block w-full border p-2 rounded focus:ring-2 focus:ring-violet-400"
        />
        <button
          onClick={handleUpload}
          className="self-start px-4 py-2 rounded-lg text-white shadow 
                     bg-gradient-to-r from-violet-400 to-sky-400 
                     hover:from-violet-500 hover:to-sky-500 transition"
        >
          Submit
        </button>
      </div>

      {json && (
        <div className="bg-white p-6 mt-6 rounded-xl shadow space-y-6">
          <h2 className="text-xl font-semibold text-violet-600">Extracted Invoice</h2>

          {/* تفاصيل الفاتورة */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
            <div><span className="font-semibold">Invoice Number:</span> {json["Invoice Number"]}</div>
            <div><span className="font-semibold">Date:</span> {json["Date"]}</div>
            <div><span className="font-semibold">Vendor:</span> {json["Vendor"]}</div>
            <div><span className="font-semibold">Category:</span> {json["Category"]}</div>
            <div><span className="font-semibold">Total Amount:</span> {json["Total Amount"]}</div>
          </div>

          {/* جدول العناصر */}
          <div>
            <h3 className="text-lg font-semibold mb-2 text-sky-600">Items</h3>
            <div className="overflow-x-auto">
              <table className="min-w-full border text-sm">
                <thead className="bg-gradient-to-r from-violet-400 to-sky-400 text-white">
                  <tr>
                    <th className="p-2 border">Description</th>
                    <th className="p-2 border">Quantity</th>
                    <th className="p-2 border">Unit Price</th>
                    <th className="p-2 border">Total</th>
                  </tr>
                </thead>
                <tbody>
                  {json.Items.map((item, i) => (
                    <tr key={i} className="text-center hover:bg-violet-50">
                      <td className="p-2 border">{item.description}</td>
                      <td className="p-2 border">{item.quantity}</td>
                      <td className="p-2 border">{item.unit_price}</td>
                      <td className="p-2 border">{item.total}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          </div>

          {/* زر الحفظ */}
          <div className="text-right">
            <button
              onClick={() => console.log("Saving invoice:", json)}
              className="px-4 py-2 rounded-lg text-white shadow 
                         bg-gradient-to-r from-violet-400 to-sky-400 
                         hover:from-violet-500 hover:to-sky-500 transition"
            >
              Confirm & Save
            </button>
          </div>
        </div>
      )}
    </div>
  );
}
