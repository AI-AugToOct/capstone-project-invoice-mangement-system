﻿import {
  PieChart, Pie, Cell,
  LineChart, Line, XAxis, YAxis, Tooltip, CartesianGrid,
  BarChart, Bar, Legend
} from "recharts";

export default function Dashboard() {
  const categoriesData = [
    { name: "Electronics", value: 1200 },
    { name: "Office Supplies", value: 800 },
    { name: "Travel", value: 500 },
  ];

  const monthlyData = [
    { month: "Jan", total: 500 },
    { month: "Feb", total: 900 },
    { month: "Mar", total: 1200 },
    { month: "Apr", total: 700 },
  ];

  const vendorsData = [
    { vendor: "ACME Corp", total: 1200 },
    { vendor: "Amazon", total: 800 },
    { vendor: "Dell", total: 600 },
  ];

  const COLORS = ["#a78bfa", "#38bdf8", "#9333ea", "#0ea5e9"];

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-violet-100 via-sky-50 to-violet-200">
      <h1 className="text-3xl font-bold mb-6 text-violet-700">Dashboard</h1>

      {/* البطاقات */}
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-6">
        <div className="bg-white p-4 rounded-xl shadow border-t-4 border-violet-400">
          <h2 className="text-gray-600">Total Invoices</h2>
          <p className="text-2xl font-bold text-violet-600">23</p>
        </div>
        <div className="bg-white p-4 rounded-xl shadow border-t-4 border-sky-400">
          <h2 className="text-gray-600">Total Spending</h2>
          <p className="text-2xl font-bold text-sky-500">$2,500</p>
        </div>
        <div className="bg-white p-4 rounded-xl shadow border-t-4 border-violet-400">
          <h2 className="text-gray-600">Top Vendor</h2>
          <p className="text-2xl font-bold text-violet-600">ACME Corp</p>
        </div>
      </div>

      {/* الرسوم البيانية */}
      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        {/* Pie chart */}
        <div className="bg-white p-4 rounded-xl shadow">
          <h2 className="mb-4 font-bold text-violet-600">Spending by Category</h2>
          <PieChart width={300} height={300}>
            <Pie
              data={categoriesData}
              dataKey="value"
              cx="50%"
              cy="50%"
              outerRadius={100}
              label
            >
              {categoriesData.map((entry, index) => (
                <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
              ))}
            </Pie>
            <Legend />
          </PieChart>
        </div>

        {/* Line chart */}
        <div className="bg-white p-4 rounded-xl shadow">
          <h2 className="mb-4 font-bold text-sky-600">Monthly Spending</h2>
          <LineChart width={400} height={300} data={monthlyData}>
            <CartesianGrid stroke="#e5e7eb" />
            <XAxis dataKey="month" />
            <YAxis />
            <Tooltip />
            <Line type="monotone" dataKey="total" stroke="#a78bfa" strokeWidth={3} />
          </LineChart>
        </div>

        {/* Bar chart */}
        <div className="bg-white p-4 rounded-xl shadow md:col-span-2">
          <h2 className="mb-4 font-bold text-violet-600">Top Vendors</h2>
          <BarChart width={600} height={300} data={vendorsData}>
            <CartesianGrid stroke="#e5e7eb" />
            <XAxis dataKey="vendor" />
            <YAxis />
            <Tooltip />
            <Legend />
            <Bar dataKey="total" fill="#38bdf8" />
          </BarChart>
        </div>
      </div>
    </div>
  );
}
