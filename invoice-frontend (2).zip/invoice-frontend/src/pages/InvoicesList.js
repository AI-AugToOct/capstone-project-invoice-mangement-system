﻿import { useState } from "react";

const mockInvoices = [
  {
    number: "INV-2025-001",
    date: "2025-10-01",
    vendor: "Demo Vendor",
    total: "100",
    category: "Office"
  },
  {
    number: "INV-2025-002",
    date: "2025-09-15",
    vendor: "Tech Supplies",
    total: "250",
    category: "Electronics"
  },
  {
    number: "INV-2025-003",
    date: "2025-09-10",
    vendor: "Coffee Shop",
    total: "45",
    category: "Food"
  }
];

export default function InvoicesList() {
  const [search, setSearch] = useState("");
  const [selected, setSelected] = useState(null); // الفاتورة المختارة

  const filtered = mockInvoices.filter(
    (inv) =>
      inv.number.toLowerCase().includes(search.toLowerCase()) ||
      inv.vendor.toLowerCase().includes(search.toLowerCase()) ||
      inv.category.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <div className="min-h-screen p-6 bg-gradient-to-br from-violet-100 via-sky-50 to-violet-200">
      <h1 className="text-2xl font-bold text-violet-700 mb-6">Invoices List</h1>

      {/* مربع البحث */}
      <div className="bg-white p-6 rounded-xl shadow mb-6">
        <input
          type="text"
          placeholder="Search by number, vendor, category..."
          value={search}
          onChange={(e) => setSearch(e.target.value)}
          className="w-full md:w-1/3 p-2 border rounded focus:ring-2 focus:ring-violet-400"
        />
      </div>

      {/* جدول الفواتير */}
      <div className="bg-white p-6 rounded-xl shadow overflow-x-auto">
        <table className="min-w-full border text-sm">
          <thead className="bg-gradient-to-r from-violet-400 to-sky-400 text-white">
            <tr>
              <th className="p-2 border">Invoice #</th>
              <th className="p-2 border">Date</th>
              <th className="p-2 border">Vendor</th>
              <th className="p-2 border">Total</th>
              <th className="p-2 border">Category</th>
            </tr>
          </thead>
          <tbody>
            {filtered.map((inv, i) => (
              <tr
                key={i}
                onClick={() => setSelected(inv)} // عند الضغط يفتح المودال
                className="text-center hover:bg-violet-50 cursor-pointer transition"
              >
                <td className="p-2 border">{inv.number}</td>
                <td className="p-2 border">{inv.date}</td>
                <td className="p-2 border">{inv.vendor}</td>
                <td className="p-2 border text-sky-600 font-semibold">{inv.total}</td>
                <td className="p-2 border">{inv.category}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>

      {/* Modal (نافذة التفاصيل) */}
      {selected && (
        <div className="fixed inset-0 bg-black/40 flex items-center justify-center z-50">
          <div className="bg-white rounded-xl shadow-xl p-6 w-full max-w-md space-y-4">
            <h2 className="text-xl font-bold text-violet-600 mb-2">Invoice Details</h2>
            <p><span className="font-semibold">Number:</span> {selected.number}</p>
            <p><span className="font-semibold">Date:</span> {selected.date}</p>
            <p><span className="font-semibold">Vendor:</span> {selected.vendor}</p>
            <p><span className="font-semibold">Total:</span> ${selected.total}</p>
            <p><span className="font-semibold">Category:</span> {selected.category}</p>

            <div className="text-right">
              <button
                onClick={() => setSelected(null)}
                className="px-4 py-2 rounded-lg text-white shadow 
                           bg-gradient-to-r from-violet-400 to-sky-400 
                           hover:from-violet-500 hover:to-sky-500 transition"
              >
                Close
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
