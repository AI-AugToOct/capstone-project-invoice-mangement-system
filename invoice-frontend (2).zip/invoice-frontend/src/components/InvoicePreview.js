export default function InvoicePreview({ invoice }) {
  if (!invoice) return null;

  return (
    <div className="bg-white p-6 rounded-lg shadow space-y-6">
      {/* Header Info */}
      <div>
        <h2 className="text-xl font-bold mb-2">Invoice Details</h2>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-sm">
          <div><span className="font-semibold">Invoice Number:</span> {invoice["Invoice Number"]}</div>
          <div><span className="font-semibold">Date:</span> {invoice["Date"]}</div>
          <div><span className="font-semibold">Vendor:</span> {invoice["Vendor"]}</div>
          <div><span className="font-semibold">Category:</span> {invoice["Category"]}</div>
          <div><span className="font-semibold">Total Amount:</span> {invoice["Total Amount"]}</div>
        </div>
      </div>

      {/* Items Table */}
      <div>
        <h3 className="text-lg font-semibold mb-2">Items</h3>
        <div className="overflow-x-auto">
          <table className="min-w-full border text-sm">
            <thead className="bg-gray-100">
              <tr>
                <th className="p-2 border">Description</th>
                <th className="p-2 border">Quantity</th>
                <th className="p-2 border">Unit Price</th>
                <th className="p-2 border">Total</th>
              </tr>
            </thead>
            <tbody>
              {(invoice.Items || []).map((item, i) => (
                <tr key={i} className="text-center">
                  <td className="p-2 border">{item.description}</td>
                  <td className="p-2 border">{item.quantity}</td>
                  <td className="p-2 border">{item.unit_price}</td>
                  <td className="p-2 border">{item.total}</td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>
      </div>

      {/* Footer */}
      <div className="text-right">
        <span className="text-lg font-bold">Grand Total: {invoice["Total Amount"]}</span>
      </div>
    </div>
  );
}
