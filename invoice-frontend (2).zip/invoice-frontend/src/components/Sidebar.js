import { Link, useLocation } from "react-router-dom";

const NavItem = ({ to, label }) => {
  const { pathname } = useLocation();
  const active = pathname === to;
  return (
    <Link
      to={to}
      className={`block px-4 py-2 rounded-md transition ${
        active ? "bg-blue-600 text-white" : "text-gray-700 hover:bg-gray-100"
      }`}
    >
      {label}
    </Link>
  );
};

export default function Sidebar() {
  return (
    <aside className="hidden md:block w-64 bg-white border-r">
      <div className="p-4 font-bold text-lg">Invoices</div>
      <nav className="space-y-1 px-2 pb-4">
        <NavItem to="/dashboard" label="Dashboard" />
        <NavItem to="/upload" label="Upload Invoice" />
        <NavItem to="/invoices" label="Invoices List" />
        <NavItem to="/chat" label="Chat with Invoices" />
      </nav>
    </aside>
  );
}
