﻿import { BrowserRouter as Router, Routes, Route, useLocation } from "react-router-dom";
import Layout from "./components/Layout";
import Dashboard from "./pages/Dashboard";
import UploadInvoice from "./pages/UploadInvoice";
import InvoicesList from "./pages/InvoicesList";
import Chat from "./pages/Chat";
import Login from "./pages/Login";

function RoutesWithLayout() {
  const location = useLocation();
  const noLayout = ["/", "/login"].includes(location.pathname);

  if (noLayout) {
    return (
      <Routes>
        <Route path="/" element={<Login />} />
      </Routes>
    );
  }

  return (
    <Layout>
      <Routes>
        <Route path="/dashboard" element={<Dashboard />} />
        <Route path="/upload" element={<UploadInvoice />} />
        <Route path="/invoices" element={<InvoicesList />} />
        <Route path="/chat" element={<Chat />} />
      </Routes>
    </Layout>
  );
}

export default function App() {
  return (
    <Router>
      <RoutesWithLayout />
    </Router>
  );
}

